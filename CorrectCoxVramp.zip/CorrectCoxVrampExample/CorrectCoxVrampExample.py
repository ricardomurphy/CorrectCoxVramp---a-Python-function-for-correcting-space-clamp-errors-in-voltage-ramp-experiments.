# -*- coding: utf-8 -*-
"""
ricardo.murphy@fastmail.fm
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

import glob
import shutil
import CorrectCoxVramp as cox

result = cox.CorrectCoxVramp('parameters.txt') 

outputdir = result['output_folder']
shutil.copy('mossy_fiber_run.hoc', outputdir+'/'+'mossy_fiber_run.hoc')
shutil.copy('mossy_fiber_setup.hoc', outputdir+'/'+'mossy_fiber_setup.hoc')
shutil.copy('mossy_fiber_morphology.hoc', outputdir+'/'+'mossy_fiber_morphology.hoc')
files = glob.glob('*.mod')
for f in files:
    shutil.copy(f, outputdir+'/'+f)
shutil.copy('CorrectCoxVrampExample.py', outputdir+'/'+'CorrectCoxVrampExample.py')
shutil.copy('CorrectCoxVramp.py', outputdir+'/'+'CorrectCoxVramp.py')
