# -*- coding: utf-8 -*-
"""
ricardo.murphy@medisin.uio.no
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

import CorrectCoxVramp as cox

result = cox.CorrectCoxVramp('parameters.txt',saveCox = 'yes') 

