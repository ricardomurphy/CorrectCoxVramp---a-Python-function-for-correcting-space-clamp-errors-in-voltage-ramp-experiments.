# -*- coding: utf-8 -*-
"""
ricardo.murphy@medisin.uio.no
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

import os
import time
import glob
import shutil
import subprocess as sb
import numpy as np
from scipy import optimize as op
from scipy import integrate as ode
from scipy import interpolate as intp
import matplotlib.pyplot as plt

def get_filenames(dir='', temp='', rec=False):
    files = []
    if len(dir) > 0:
        files = glob.glob(dir+'\\'+temp, recursive=rec)
    else:
        files = glob.glob(temp)
    return files

def delete_file(fn):
    file = glob.glob(fn)
    if len(file) > 0: os.remove(file[0])
    
def load_xyz(fn,xc,yc,zc):
    file = open(fn,'r')
    data = file.readlines(); file.close()
    n = len(data)-1; x = np.zeros(n)
    y = np.zeros(n); z = np.zeros(n)
    i = 0
    while i < n:
        v = data[i+1].split()
        x[i] = float(v[xc])
        y[i] = float(v[yc])
        z[i] = float(v[zc])
        i = i + 1
    return x,y,z
        
def load_xy(fn,xc,yc):
    file = open(fn,'r')
    data = file.readlines(); file.close()
    n = len(data)-1; x = np.zeros(n)
    y = np.zeros(n); i = 0
    while i < n:
        v = data[i+1].split()
        x[i] = float(v[xc])
        y[i] = float(v[yc])
        i = i + 1        
    return x,y
    
def load_x(fn,xc):
    file = open(fn,'r')
    data = file.readlines(); file.close()
    n = len(data)-1; x = np.zeros(n)
    i = 0
    while i < n:
        v = data[i+1].split()
        x[i] = float(v[xc])
        i = i + 1        
    return x    

def calcIcap(Vhold,Ihold,V,I):
    n = len(V); Icap = 0; 
    i = 1
    while i < n:
        if i > 0 and np.sign(Vhold-V[i-1]) != np.sign(Vhold-V[i]):
            b = (I[i]-I[i-1])/(V[i]-V[i-1])
            Icap = I[i-1] + b*(Vhold - V[i-1]) - Ihold
            break
        i = i + 1
    if Icap == 0:
        raise ValueError("Apparently V doesn't span Vhold; can't estimate Icap.")
    return Icap

def getVrest(m,p,V1,V2):
    if m > 0:
        V = np.roots(p)
    else:
        V = p.roots()
    Vr = np.isreal(V)
    Vrest = []; i = 0
    while i < len(Vr):
        realV = np.real(V[i])
        if Vr[i] == True and realV >= V1 and realV <= V2: 
            Vrest.append(realV)
        i = i + 1
    return Vrest
    
def EstimateVrest(i,poly,p,V0,Vrest,Voff=0,DV=0.1):
    m = len(poly)
    if (m == 1 or m == 2) and isinstance(poly[0], int):
        b = dpoly(p,V0)
    elif m == 0:
        b = dlinterp(p,V0,DV)
    else:
        bp = p.derivative(); b = bp(V0)
    if b != 0:
        if (m == 1 or m == 2) and isinstance(poly[0], int):
            a = np.polyval(p,V0)
        else:
            a  = p(V0)
        Vrest0 = V0 - a/b + Voff
        if i == 1 and Vrest0-Voff < V0: Vrest.append(Vrest0)
        if i == 2 and Vrest0-Voff > V0: Vrest.append(Vrest0)
    return Vrest

def linterpol(x1,y1,x2,y2,x):
    b = (y2-y1)/(x2-x1)
    y = y1 + b*(x-x1)
    return y

def dpoly(p,V):
    m = len(p)-1
    p = np.flip(p)
    pd = np.zeros(m)
    i = 0
    while i < m:
        pd[i] = (i+1)*p[i+1]
        i = i + 1
    pd = np.flip(pd)
    return np.polyval(pd,V)
    
def best_fit_poly(V,I,poly):
    sse0 = np.var(I)*(len(I)-1)
    i = 1
    while i <= poly[0]: #poly[0] = maximum polynomial degree.
        result = np.polyfit(V,I,i,full=True)
        p = result[0]; sse = result[1][0]
        F = (len(I)-i-1)*(sse0 - sse)/sse
        if F > poly[1]:   #poly[1] = critical F-to-enter
            sse0 = sse
        else:
            break
        i = i + 1
    return p
    
def dlinterp(p,V,DV):
    pV = p(V)
    b1 = (p(V+DV)-pV)/DV
    b2 = (pV-p(V-DV))/DV
    return 0.5*(b1+b2)    

def smooth(k,V,I,poly,Veval,doplot,legend,colr,ls,Rseal=np.Inf):
    if doplot == 'yes':
        fig = plt.figure(k)
        plt.plot(V,I,linewidth=5.0,color=colr)
        plt.xlabel('$V$ (mV)')
        plt.ylabel('$I$ (pA)')
        if k == 0:
            if Rseal == np.Inf:
                plt.title('Raw I and I corrected for Cm')
            elif Rseal < 0:
                plt.title('Raw I: poly = ' + str(poly))
            else:
                plt.title('Raw I and I corrected for Rseal and Cm')
        else:
            plt.title('Iteration: '+str(k-1))
    m = len(poly); n = len(V)
    if m == 0:
        p = intp.interp1d(V,I,fill_value='extrapolate')
        I = np.zeros(n); I = p(Veval)
        Vrest = []; i = 1
        while i < len(I):
            if np.sign(I[i]) != np.sign(I[i-1]):
                b = (I[i]-I[i-1])/(Veval[i]-Veval[i-1])
                V0 =  -I[i-1]/b + Veval[i-1]; Vrest.append(V0)
            i = i + 1
        Vrest = np.array(Vrest)
    elif m == 1 and isinstance(poly[0], int):
        p = np.polyfit(V,I,poly[0])
        I = np.zeros(n); I = np.polyval(p,Veval)
        Vrest = getVrest(m,p,V[0],V[len(V)-1])
    elif m == 2:
        p = best_fit_poly(V,I,poly)
        I = np.zeros(n); I = np.polyval(p,Veval)
        Vrest = getVrest(m,p,V[0],V[len(V)-1])
    else:
        p0 = np.array([poly[2]])   #polynomials of degree poly[0] and poly[1] are joined at V = poly[2]
        V1 = V.copy(); I1 = I.copy(); i1 = 0
        V2 = V.copy(); I2 = I.copy(); i2 = 0
        i = 0; n = len(V)
        while i < n:
            if V[i] <= poly[2]:
                V1[i1] = V[i]
                I1[i1] = I[i]
                i1 = i1 + 1
            else:
                V2[i2] = V[i]
                I2[i2] = I[i]
                i2 = i2 + 1
            i = i + 1
        V1 = np.resize(V1,i1)
        I1 = np.resize(I1,i1)
        V2 = np.resize(V2,i2)
        V2 = V2 - poly[2]
        I2 = np.resize(I2,i2)
        p1 = np.polyfit(V1,I1,poly[0])
        p2 = np.polyfit(V2,I2,poly[1])
        p2 = np.resize(p2,np.size(p2)-2)  #0 and 1 degree terms of polynomial 2 are estimated by fun to get a smooth and continuous join.
        p0 = np.concatenate((p0,p1,p2))
        res = op.least_squares(resids, p0, args = (V,I,poly))
        I = np.zeros(n); I = fun(res.x,Veval,poly)
        p = res.x; p1,p2 = polyparas(p,poly)
        Vrest1 = getVrest(m,p1,V[0],p[0])
        Vrest2 = getVrest(m,p2,0,V[len(V)-1]-p[0]) + p[0]
        Vrest = Vrest1; i = 0
        while i < len(Vrest2):
            Vrest.append(Vrest2[i])
            i = i + 1
    if doplot == 'yes':
        if Rseal < 0:
            plt.plot(Veval,I,ls,linewidth=1.0,color='0.0')
        else:
            plt.plot(Veval,I,ls,linewidth=1.0)
        if len(legend) > 0: plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
    return I, Vrest, p
    
def test_smooth(parameter_file, Iunit='pA'):
    file = open(parameter_file,'r')
    data = file.readlines(); file.close()
    tbreak = [0,0,0]; i = 0
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':')
        v[1] = v[1].strip()
        if len(v[1]) > 0:
            if v[0] == 'tVIfile': tVIfile = v[1]
            if v[0] == 'Iunit': Iunit = v[1]
            if v[0] == 'V_LJP_corrected': V_LJP_corrected = v[1]
            if v[0] == 'LJP(mV)': LJP = float(v[1])
            if v[0] == 'tstart(ms)': tbreak[2] = float(v[1])
            if v[0] == 'poly': 
                v = v[1].split()
                poly = []; j = 0
                while j < len(v):
                    if j == 0 or (j == 1 and len(v)) == 3:
                        poly.append(int(v[j]))
                    else:
                        poly.append(float(v[j]))
                    j = j + 1
            i = i + 1
    t,V,I = load_xyz(tVIfile,0,1,2)
    if Iunit != 'pA': I = 1000*I  #nA -> pA
    if V_LJP_corrected == 'no': V = V - LJP
    Vtmp = V.copy(); Itmp = I.copy()
    n = len(V); i = 0; ii = 0
    while i < n:
        if t[i] > tbreak[2]:
            Vtmp[ii] = V[i]
            Itmp[ii] = I[i]
            ii = ii + 1
        i = i + 1
    n = ii
    V = np.resize(Vtmp,n); I = np.resize(Itmp,n) 
    I = smooth(0,V,I,poly,V,'yes',['Raw I','Smoothed'],'0.6','k-',Rseal=-1)[0]
        
def resids(p,V,I,poly):
    Ihat = fun(p,V,poly)
    return I-Ihat
        
def fun(p,V,poly): 
    n = len(V); I = np.zeros(n)
    p1,p2 = polyparas(p,poly)
    i = 0
    while i < n:
        if V[i] <= p[0]:   #polynomials p1 and p2 are joined at V = p[0]
            I[i] = np.polyval(p1,V[i])
        else:
            I[i] = np.polyval(p2,V[i]-p[0])
        i = i + 1
    return I
    
def polyparas(p,poly):
    np1 = poly[0]+1   #poly[0] = degree of polynomial 1
    p1 = np.zeros(np1)
    i = 0
    while i < np1:
        p1[i] = p[i+1]
        i = i + 1
    np2 = poly[1]+1   #poly[1] = degree of polynomial 2
    p2 = np.zeros(np2)
    i = 0
    while i < np2-2:
        p2[i] = p[np1+1+i]
        i = i + 1
    p2[i] = dpoly(p1,p[0])  #0 and 1 degree terms of polynomial 2 are estimated from polynomial 1 to get a smooth and continuous join.  
    p2[i+1] = np.polyval(p1,p[0])
    return p1, p2

def solveODE(V,Vrest,A,gamma,DV,p,poly,options):
    m = len(poly)
    if m == 1 and isinstance(poly[0], float):
        dIstar_dV0 = p(Vrest,1)
    elif m == 0:
        dIstar_dV0 = dlinterp(p,Vrest,DV)
    elif (m == 1 or m == 2) and isinstance(poly[0], int):
        dIstar_dV0 = dpoly(p,Vrest)
    else:
        p1,p2 = polyparas(p,poly)
        if Vrest <= p[0]:
            dIstar_dV0 = dpoly(p1,Vrest)
        else:
            dIstar_dV0 = dpoly(p2,Vrest-p[0])
    factor = gamma*gamma + 16*gamma*A*dIstar_dV0
    if factor >= 0:
        slope = (gamma + 8*A*dIstar_dV0 - np.sqrt(factor))/(8*A*A)
    else:
        slope = (gamma + 8*A*dIstar_dV0)/(8*A*A)
        print("WARNING: (dI/dV)_Vrest < -gamma/(16*A) in Eq. (15).")
        print("         Setting the sqrt term to zero.")
    Ve0 = []; Ve1 = []; Ve2 = []
    Ve01 = Vrest-DV; Ve02 = Vrest+DV
    n = len(V); i = 0
    while i < n:
        if V[i] < Ve01: 
            Ve1.append(V[i])
        elif V[i] > Ve02: 
            Ve2.append(V[i])
        else:
            Ve0.append(V[i])
        i = i + 1
    Ve1 = np.array(Ve1); Ve2 = np.array(Ve2)
    Ve1 = np.flip(-np.array(Ve1)); Ve01 = -Ve01
    n1 = len(Ve1); n2 = len(Ve2); n0 = len(Ve0)
    cd1 = np.zeros(n1); cd2 = np.zeros(n2)
    #options = {'rtol': 1e-5,'atol': 1e-8,'max_step': 0.01}
    if n1 > 0:
        cd0 = np.array([-slope*DV]); mult = -1
        sol1 = ode.solve_ivp(fun=lambda t,y: dcddV(t,y,A,gamma,p,poly,mult,DV),t_span=(Ve01,Ve1[n1-1]),y0=cd0,t_eval=Ve1,method='RK45',**options)  
        cd1 = sol1.y[0]; cd1 = np.flip(cd1)
    if n2 > 0:
        cd0 = np.array([slope*DV]); mult = 1
        sol2 = ode.solve_ivp(fun=lambda t,y: dcddV(t,y,A,gamma,p,poly,mult,DV),t_span=(Ve02,Ve2[n2-1]),y0=cd0,t_eval=Ve2,method='RK45',**options)
        cd2 = sol2.y[0]
    cd0 = np.zeros(n0)
    if n0 > 0: 
        i = 0
        while i < n0:
            cd0[i] = slope*(Ve0[i]-Vrest)
            i = i + 1
    cd = np.concatenate((cd1,cd0,cd2))
    return cd

def dcddV(V,cd,A,gamma,p,poly,mult,DV):
    V = mult*V; m = len(poly)
    if m == 1 and isinstance(poly[0], float):
        Istar = p(V)
        dIstar_dV = p(V,1)
    elif m == 0:
        Istar = p(V)
        dIstar_dV = dlinterp(p,V,DV)
    elif (m == 1 or m == 2) and isinstance(poly[0], int):
        Istar = np.polyval(p,V)
        dIstar_dV = dpoly(p,V)
    else:
        p1,p2 = polyparas(p,poly)
        if V <= p[0]:
            Istar = np.polyval(p1,V)
            dIstar_dV = dpoly(p1,V)
        else:
            Istar = np.polyval(p2,V-p[0])
            dIstar_dV = dpoly(p2,V-p[0])
    dcd_dV = mult*(gamma*cd[0]/(4*(A*cd[0]-Istar)) + dIstar_dV)/A
    return dcd_dV
    
def CorrectVramp(k,tbreak,A,Ra,t=[],V=[],I=[],d=[],Raccess=0, color=['0.6','0.8'], 
                    Rseal=np.Inf,Cm=1.0,LJP=0.0,poly=[5,4.0],DV=0.1, Iunit='pA', 
                    V_LJP_corrected = 'yes', data_lw = 5.0, criterion = 'I&Icap', 
                    tVIfile = '', flagfile = 'flag.txt',  
                    do_plots='no', VRm=[], options = {}, cwd = os.getcwd(), 
                    parameter_file = 'parameters.txt', gLfrac = 0.01, 
                    coxdir='CorrectCoxVramp',  
                    maxIerror_tol = 1.0, Icap_error_tol = 0.1, maxit = 9):
    file = open(parameter_file,'r')
    data = file.readlines(); file.close()
    i = 0; tbreak = [0,0,0]; calc_gL = 'no'
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':')
        v[1] = v[1].strip()
        #if len(v[1]) > 0:
        if v[0] == 'maxit': maxit = int(v[1])
        if v[0] == 'Interpolation': Linear_interpolation = v[1]
        if v[0] == 'DV(mV)': DV = float(v[1])
        if v[0] == 'Iunit': Iunit = v[1]
        if v[0] == 'V_LJP_corrected': V_LJP_corrected = v[1]
        if v[0] == 'do_plots': do_plots = v[1]
        if v[0] == 'tVIfile': tVIfile = v[1]
        if v[0] == 'Area(um^2)': A = float(v[1])
        if v[0] == 'Ra(Ohm.cm)': Ra = float(v[1])
        if v[0] == 'Raccess(MOhm)': Raccess = float(v[1])
        if v[0] == 'Rseal(GOhm)': Rseal = float(v[1])
        if v[0] == 'Cm(uF/cm^2)' and k == 0: Cm = float(v[1])
        if v[0] == 'LJP(mV)': LJP = float(v[1])
        if v[0] == 'gL_fraction' and len(v) > 1: 
            gLfrac = float(v[1])
            calc_gL = 'yes'
        if v[0] == 'diam(um)': 
            v = v[1].split()
            d = []; j = 0
            while j < len(v):
                d.append(float(v[j]))
                j = j + 1
        if v[0] == 'VRm(mV)' and len(v) > 1: 
            v = v[1].split()
            VRm = []; j = 0
            while j < len(v):
                VRm.append(float(v[j]))
                j = j + 1
            calc_Rm = 'yes'
        if v[0] == 'thold(ms)': tbreak[1] = float(v[1])
        if v[0] == 'tstart(ms)': tbreak[2] = float(v[1])
        if v[0] == 'poly': 
            v = v[1].split()
            poly = []; j = 0
            while j < len(v):
                if j == 0 and '.' in v[j]:
                    poly.append(float(v[j]))
                elif j == 0 or (j == 1 and len(v) == 3):
                    poly.append(int(v[j]))
                else:
                    poly.append(float(v[j]))
                j = j + 1
        i = i + 1
    if k == 0:
        try:
            os.chdir(coxdir)
            os.chdir(cwd)
            shutil.rmtree(coxdir, ignore_errors=True)
            os.rmdir(coxdir)
            os.mkdir(coxdir)
        except FileNotFoundError:
            os.mkdir(coxdir)
        if len(tVIfile) > 0: t,V,I = load_xyz(tVIfile,0,1,2)
        if Iunit != 'pA': I = 1000*I  #nA -> pA
        if V_LJP_corrected == 'no': V = V - LJP
        Vtmp = V.copy(); Itmp = I.copy()
        n = len(V); sumIhold = 0; sumVhold = 0; nhold = 0
        i = 0; ii = 0
        while i < n:
            if t[i] > tbreak[0] and t[i] < tbreak[1]: 
                sumIhold = sumIhold + I[i]
                sumVhold = sumVhold + V[i]
                nhold = nhold + 1
            if t[i] > tbreak[2]:
                Vtmp[ii] = V[i]
                Itmp[ii] = I[i]
                ii = ii + 1
            i = i + 1
        n = ii
        V = np.resize(Vtmp,n); I = np.resize(Itmp,n) 
        Vhold = sumVhold/nhold; Ihold = sumIhold/nhold
        I = smooth(k,V,I,poly,V,'yes',[],'0.6','k-',Rseal=Rseal)[0]
        file = open('Raw_tVI.txt','w')
        file.write('%10s'%'t(ms)'+'%10s'%'V(mV)'+'%15s'%'I(pA)'+'\r')
        i = 0
        while i < n:
            file.write('%10.3f'%t[i]+'%10.3f'%V[i]+'%15e'%I[i]+'\r')
            i = i + 1
        file.close()
        if Raccess > 0:
            Vhold = Vhold - Ihold*Raccess*1e-3
            i = 0
            while i < n:
                V[i] = V[i] - I[i]*Raccess*1e-3
                i = i + 1
        if np.isfinite(Rseal):
            Eseal = -LJP
            Ihold = Ihold - (Vhold-Eseal)/Rseal
            i = 0
            while i < n:
                I[i] = I[i] - (V[i]-Eseal)/Rseal
                i = i + 1
        obsIcap = calcIcap(Vhold,Ihold,V,I)
        I = I - obsIcap
        file = open('tVI.txt','w')
        file.write('%10s'%'t(ms)'+'%10s'%'V(mV)'+'%15s'%'I(pA)'+'\r')
        i = 0
        while i < n:
            file.write('%10.3f'%t[i]+'%10.3f'%V[i]+'%15e'%I[i]+'\r')
            i = i + 1
        file.close()
        file = open('IcapIholdVholdVrest.txt','w')
        file.write(' Icap(pA): %7.2f'%obsIcap+'\r')
        file.write('Ihold(pA): %7.2f'%Ihold+'\r')
        file.write('Vhold(mV): %7.2f'%Vhold+'\r')        
        file.close()
        Istar_k = I.copy()
        result = {'t (ms)': t, 'V (mV)': V, 'I (pA)': I}
    else:
        rawV,rawI = load_xy('Raw_tVI.txt',1,2)
        t,V,I = load_xyz('tVI.txt',0,1,2); n = len(V)
        file = open('IcapIholdVholdVrest.txt','r')
        data = file.readlines(); file.close()
        v = data[0].split(); obsIcap = float(v[1])
        tp,Vp,predI = load_xyz('tVpredI.txt',0,1,2)

        if Iunit != 'pA': predI = 1000*predI  #nA -> pA
        ttmp = tp.copy(); Vtmp = Vp.copy(); Itmp = predI.copy()
        m = len(Vp); sumIhold = 0; sumVhold = 0; nhold = 0
        i = 0; ii = 0
        while i < m:
            if tp[i] > tbreak[0] and tp[i] < tbreak[1]: 
                sumIhold = sumIhold + predI[i]
                sumVhold = sumVhold + Vp[i]
                nhold = nhold + 1
            if tp[i] > tbreak[2]:
                ttmp[ii] = tp[i]
                Vtmp[ii] = Vp[i]
                Itmp[ii] = predI[i]
                ii = ii + 1
            i = i + 1
        m = ii
        Vp = np.resize(Vtmp,m); predI = np.resize(Itmp,m)
        tp = np.resize(ttmp,m)
        predVhold = sumVhold/nhold; predIhold = sumIhold/nhold
        predI = smooth(k,Vp,predI,poly,Vp,do_plots,[],'0.6','k-')[0]  #is this necessary or desirable?
        rawpredI = predI.copy(); rawpredV = Vp.copy()
        file = open(coxdir+'/Raw_tVpredI_'+str(k-1)+'.txt','w')
        file.write('%15s'%'t(ms)'+'%15s'%'V(mV)'+'%15s'%'I(pA)'+'\r')
        i = 0
        while i < len(rawpredI):
            file.write('%15.2f'%tp[i]+'%15.3f'%rawpredV[i]+'%15e'%rawpredI[i]+'\r')
            i = i + 1
        file.close()
        if Raccess > 0:
            predVhold = predVhold - predIhold*Raccess*1e-3
            i = 0
            while i < m:
                Vp[i] = Vp[i] - predI[i]*Raccess*1e-3
                i = i + 1
        if np.isfinite(Rseal):
            Eseal = -LJP
            predIhold = predIhold - (predVhold-Eseal)/Rseal
            i = 0
            while i < m:
                predI[i] = predI[i] - (Vp[i]-Eseal)/Rseal
                i = i + 1
        
        predIcap = calcIcap(predVhold,predIhold,Vp,predI)
        predI = predI - predIcap
        predI,Vrest,p = smooth(k,Vp,predI,poly,V,do_plots,[],'0.75','r-')
        if do_plots == 'yes': plt.plot(rawV,rawI,'k--'); plt.plot(V,I,'k-.')
        e_k1 = np.zeros(n); i = 0
        while i < n:
            e_k1[i] = I[i] - predI[i]
            i = i + 1
        file = open(coxdir+'/tVpredI_'+str(k-1)+'.txt','w')
        file.write('%15s'%'t(ms)'+'%15s'%'V(mV)'+'%15s'%'I(pA)'+'\r')
        i = 0
        while i < n:
            file.write('%15.2f'%t[i]+'%15.3f'%V[i]+'%15e'%predI[i]+'\r')
            i = i + 1
        file.close()
        file = open(coxdir+'/Ierror_'+str(k-1)+'.txt','w')
        file.write('%10s'%'V(mV)'+'%15s'%'Ierror(pA)'+'\r')
        i = 0
        while i < n:
            file.write('%10.3f'%V[i]+'%15e'%e_k1[i]+'\r')
            i = i + 1
        file.close()
        file = open(coxdir+'/PredIcapIholdVholdVrest_'+str(k-1)+'.txt','w')
        file.write(' PredictedIcap(pA): %7.2f'%predIcap+'\r')
        file.write('PredictedIhold(pA): %7.2f'%predIhold+'\r')
        file.write('PredictedVhold(mV): %7.2f'%predVhold+'\r')  
        file.write('PredictedVrest(mV): %7.2f'%min(Vrest)+'\r') 
        file.close()
        maxIerror = np.max(np.abs(e_k1))
        Icap_error = obsIcap - predIcap
        result = {'t (ms)': t, 'V (mV)': V, 'I (pA)': I}
        result['predI (pA)'] = predI
        result['Icap_error (pA)'] = Icap_error
        result['maxIerror (pA)'] = maxIerror
        done = 0
        if criterion == 'I&Icap' and abs(maxIerror) < maxIerror_tol and abs(Icap_error) < Icap_error_tol: done = 1
        if criterion == 'I' and abs(maxIerror) < maxIerror_tol: done = 1
        result['done'] = done
        if done == 1:
            result['Cm (uF/cm^2)'] = Cm
            return result

        Istarf = coxdir+'/Istar_'+str(k-1)+'.txt'
        Istar_k1 = load_x(Istarf,1)
        linterp = np.zeros(n); fsave = np.zeros(n)
        x1 = np.zeros(n); x2 = np.zeros(n)
        fx1 = np.zeros(n); fx2 = np.zeros(n)
        F1 = np.zeros(n); F2 = np.zeros(n)
        if k > 1:
            linterpf = coxdir+'/linterp_'+str(k-1)+'.txt'
            linterp = load_x(linterpf,0)
            x1, fx1 = load_xy(linterpf,1,2)
            x2, fx2 = load_xy(linterpf,3,4)
            fsave = load_x(linterpf,5)
            F1, F2 = load_xy(linterpf,6,7)
            linterp = linterp.astype(int)
            Istarf = coxdir+'/Istar_'+str(k-2)+'.txt'
            Istar_k2 = load_x(Istarf,1)
            file = coxdir+'/Ierror_'+str(k-2)+'.txt'
            e_k2 = load_x(file,1)
            if k > 2:
                Istarf = coxdir+'/Istar_'+str(k-3)+'.txt'
                Istar_k3 = load_x(Istarf,1)
                file = coxdir+'/Ierror_'+str(k-3)+'.txt'
                e_k3 = load_x(file,1)
        Istar_k = np.zeros(n)
        i = 0
        while i < n:
            if k == 1:
                Istar_k[i] = Istar_k1[i] + e_k1[i]
            elif Linear_interpolation == 'simple':
                if np.sign(e_k1[i]) == np.sign(e_k2[i]):
                    Istar_k[i] = Istar_k1[i] + e_k1[i]
                else:
                    Istar_k[i] = Istar_k1[i] - e_k1[i]*(Istar_k1[i] - Istar_k2[i])/(e_k1[i] - e_k2[i])
            elif Linear_interpolation == 'standard':
                if k == 2 or linterp[i] == 0:
                    if np.sign(e_k1[i]) == np.sign(e_k2[i]):
                        Istar_k[i] = Istar_k1[i] + e_k1[i]
                    else:
                        x1[i] = Istar_k2[i]; fx1[i] = e_k2[i]
                        x2[i] = Istar_k1[i]; fx2[i] = e_k1[i]
                        Istar_k[i] = x2[i] - fx2[i]*(x2[i] - x1[i])/(fx2[i] - fx1[i])
                        linterp[i] = 1
                else:
                    x3 = Istar_k1[i]; fx3 = e_k1[i]
                    if fx2[i] - fx1[i] == 0:
                        Istar_k[i] = x3 + fx3
                    else:
                        if np.sign(fx3) != np.sign(fx1[i]):
                            x2[i] = x3; fx2[i] = fx3
                        else:
                            x1[i] = x3; fx1[i] = fx3
                        Istar_k[i] = x2[i] - fx2[i]*(x2[i] - x1[i])/(fx2[i] - fx1[i])
            else:                        
                if k == 2 or linterp[i] == 0:
                    if np.sign(e_k1[i]) == np.sign(e_k2[i]):
                        Istar_k[i] = Istar_k1[i] + e_k1[i]
                    else:
                        x1[i] = Istar_k2[i]; fx1[i] = e_k2[i]
                        x2[i] = Istar_k1[i]; fx2[i] = e_k1[i]
                        Istar_k[i] = x2[i] - fx2[i]*(x2[i] - x1[i])/(fx2[i] - fx1[i])
                        linterp[i] = 1; fsave[i] = fx2[i]
                        F1[i] = fx1[i]; F2[i] = fx2[i]
                else:
                    x3 = Istar_k1[i]; fx3 = e_k1[i]
                    if fx2[i] - fx1[i] == 0:
                        Istar_k[i] = x3 + fx3
                    else:
                        if np.sign(fx3) != np.sign(F1[i]):
                            x2[i] = x3; F2[i] = fx3
                            if np.sign(fx3) == np.sign(fsave[i]):
                                F1[i] = 0.5*F1[i]
                        else:
                            x1[i] = x3; F1[i] = fx3
                            if np.sign(fx3) == np.sign(fsave[i]):
                                F2[i] = 0.5*F2[i]
                        fsave[i] = fx3
                        Istar_k[i] = x2[i] - F2[i]*(x2[i] - x1[i])/(F2[i] - F1[i])
            i = i + 1

    sumd32 = 0; i = 0
    while i < len(d):
        sumd32 = sumd32 + d[i]**(3/2)
        i = i + 1
    gamma = (np.pi**2/Ra)*sumd32*sumd32*1e5  #(pA/mV)um^2 with Ra in Ohm*cm
    if k == 0: 
        do_plots = 'yes'
        legend = ['Obs raw I','Smoothed','Obs crct I','Smoothed']
    else:
        legend = ['Raw predicted I','Fitted','Corrected predicted I','Fitted','Raw observed I','Corrected observed I','I*','Fitted']
    Istar_k,Vrest,p = smooth(k,V,Istar_k,poly,V,do_plots,legend,'0.85','b-')
    Istarf = open(coxdir+'/Istar_'+str(k)+'.txt','w')
    Istarf.write('%10s'%'V(mV)'+'%15s'%'I*(pA)'+'\r')
    i = 0
    while i < n:
        Istarf.write('%10.3f'%V[i]+'%15e'%Istar_k[i]+'\r')
        i = i + 1
    Istarf.close() 
    if len(Vrest) == 0:
        m = len(poly)
        if m < 3:
            Vrest = EstimateVrest(1,poly,p,V[0],Vrest)
            Vrest = EstimateVrest(2,poly,p,V[n-1],Vrest)
        else:
            p1,p2 = polyparas(p,poly)
            Vrest = EstimateVrest(1,'1',p1,V[0],Vrest)
            Vrest = EstimateVrest(2,'2',p2,V[n-1]-p[0],Vrest,Voff=p[0])
        if len(Vrest) == 0:
            raise ValueError("Unable to estimate Vrest. Stopping.")
        else:
            print("WARNING: Apparently I*(V) doesn't span zero")
            print("         Estimating Vrest by extrapolation.")
    if k > 0: print('Vrest = ', Vrest)
    cd = np.array([]); j = 0
    nVrest = len(Vrest)
    if nVrest > 1 and k == 0:
        print('WARNING: I(V) has more than one equilibrium point.')
        print('         The most negative one will be reported as Vrest.')
    while j < nVrest:
        if j == 0:
            V1 = V[0]
            if nVrest > 1:
                V2 = Vrest[j+1] - DV
            else:
                V2 = V[n-1]
        elif j < nVrest-1:
            V1 = Vrest[j] - DV
            V2 = Vrest[j+1] - DV
        else:
            V1 = Vrest[j] - DV
            V2 = V[n-1]
        Vj = []; i = 0
        while i < n:
            if V1 <= V[i] and V[i] <= V2:
                Vj.append(V[i])
            i = i + 1
        Vj = np.array(Vj)
        cdj = 0.1*solveODE(Vj,Vrest[j],A,gamma,DV,p,poly,options)  #pA/um^2 -> mA/cm^2
        cd = np.concatenate((cd,cdj))
        j = j + 1
    if do_plots == 'yes' and k > 0:
        figcd = plt.figure(-k)
        plt.plot(V,cd)
        plt.ylabel('$i$ (mA cm$^{\minus2}$)')
        plt.xlabel('$V$ (mV)')
        plt.title('Iteration: '+str(k-1))

    if k > 0:
        if criterion == 'I&Icap': Cm = Cm*(obsIcap/predIcap)
        linterpf = open(coxdir+'/linterp_'+str(k)+'.txt','w')
        #linterpf.write('%10s'%'linterp'+'%15s'%'x1'+'%15s'%'fx1'+'%15s'%'x2'+'%15s'%'fx2'+'\r')
        linterpf.write('%10s'%'linterp'+'%15s'%'x1'+'%15s'%'fx1'+'%15s'%'x2'+'%15s'%'fx2'+'%15s'%'fsave'+'%15s'%'F1'+'%15s'%'F2'+'\r')
        i = 0
        while i < n:
            linterpf.write('%10d'%linterp[i]+'%15e'%x1[i]+'%15e'%fx1[i]+'%15e'%x2[i]+'%15e'%fx2[i]+'%15e'%fsave[i]+'%15e'%F1[i]+'%15e'%F2[i]+'\r')
            i = i + 1
        linterpf.close()
    else:
        file = open('IcapIholdVholdVrest.txt','a')
        file.write('Vrest(mV): %7.2f'%min(Vrest)+'\r')
        file.close()
    file = open('cd.txt','w')
    file.write('%10s'%'V(mV)'+'%15s'%'i(mA/cm^2)'+'\r')
    i = 0; m = int(gLfrac*n)
    VL = []; cdL = []
    if len(VRm) > 0 and VRm[0] < V[1]: VRm[0] = V[1]
    while i < n:
        file.write('%10.3f'%V[i]+'%15e'%cd[i]+'\r')
        if i > 0 and len(VRm) > 0:
            if V[i-1] <= VRm[0] and VRm[0] <= V[i]: 
                cd1 = linterpol(V[i-1],cd[i-1],V[i],cd[i],VRm[0])
            if V[i-1] <= VRm[1] and VRm[1] <= V[i]: 
                cd2 = linterpol(V[i-1],cd[i-1],V[i],cd[i],VRm[1])
        if i <= m:
            VL.append(V[i])
            cdL.append(cd[i])
        i = i + 1
    file.close()
    VL = np.array(VL); cdL = np.array(cdL)
    shutil.copy('cd.txt', coxdir+'/cd_'+str(k)+'.txt')
    
    file = open('CmRmL.txt','w')
    file.write('  Cm (uF/cm^2): %7.2f'%Cm+'\r')
    if len(VRm) > 0:
        if cd1 != cd2:
            Rm = 0.001*(VRm[1] - VRm[0])/(cd2 - cd1)
            file.write('Rm (kOhm.cm^2): %7.3f'%Rm+'\r')
            iRm = [cd1,cd2]
        else:
            Rm = np.nan
            file.write('Rm (kOhm.cm^2): Inf\r')
    else:
        Rm = np.nan
        file.write('Rm (kOhm.cm^2): N/A\r')
    if calc_gL == 'yes':    
        p = best_fit_poly(VL,cdL,[2,4.0])
        if len(p) == 2:
            b = p[0]
            a = p[1]
        else:
            b = dpoly(p,V[0])
            a = np.polyval(p,V[0]) + b*(-V[0])
        gL = b
        file.write('   gL (S/cm^2): %13.5e'%b+'\r')
        if b != 0:
            EL = -a/b
            file.write('    ELeak (mV): %7.1f'%EL+'\r')
        else:
            EL = np.nan
            file.write('    ELeak (mV): NaN\r')
    else:
        file.write('   gL (S/cm^2): N/A\r')
        file.write('    ELeak (mV): N/A\r')
    file.close()
    shutil.copy('CmRmL.txt', coxdir+'/CmRmL_'+str(k)+'.txt')
    fn = tVIfile.split('.')[0]
    shutil.copy('tVpredI.txt', coxdir+'/Pred_'+fn+'_'+str(k)+'.txt')
    os.chdir(cwd)
    result['Cm (uF/cm^2)'] = Cm
    result['cd (mA/cm^2)'] = cd
    return result
    
def CorrectCoxVramp(parameter_file,tbreak=[],Area=0,Ra=100,t=[],V=[],I=[],diam=[],Raccess=0, 
                    Rseal=np.Inf,Cm=1.0,LJP=0.0,poly=[5,4.0], DV=0.1, Iunit='pA', 
                    V_LJP_corrected='yes', data_lw=5.0, outputdir='output', cwd = os.getcwd(),
                    tVIfile='', flagfile='flag.txt', coxdir='CorrectCoxVramp', 
                    do_plots='no', maxit=9, maxIerror_tol=1.0,  
                    Icap_error_tol=0.1, VRm=[], options = {}, saveCox = 'no', 
                    criterion = 'I&Icap', gLfrac = 0.01, color=['0.6','0.8']):
    
    plt.close('all'); plot_Rm = 'no'; plot_gL = 'no'
    file = open(parameter_file,'r')
    data = file.readlines(); file.close()
    i = 0
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':')
        v[1] = v[1].strip()
        if len(v[1]) > 0:
            if v[0] == 'neuron_file': neuron_file = v[1]
            if v[0] == 'tVIfile': tVIfile = v[1]
            if v[0] == 'maxit': maxit = int(v[1])
            if v[0] == 'do_plots': do_plots = v[1]
            if v[0] == 'Optimise_Cm': 
                criterion = 'I&Icap'
                if v[1] == 'no': criterion = 'I'
            if v[0] == 'coxdir': coxdir = v[1]
            if v[0] == 'outputdir': outputdir = v[1]
            if v[0] == 'maxIerror_tol(pA)': maxIerror_tol = float(v[1])
            if v[0] == 'Icap_error_tol(pA)': Icap_error_tol = float(v[1])
            if v[0] == 'Raccess(MOhm)': Raccess = float(v[1])
            if v[0] == 'gL_fraction' and len(v) > 1: 
                gLfrac = float(v[1])
                plot_gL = 'yes'
            if v[0] == 'VRm(mV)' and len(v) > 1:  
                VRm = []; v = v[1].split()
                VRm.append(float(v[0]))
                VRm.append(float(v[1]))
                plot_Rm = 'yes'
        i = i + 1
    try:
        os.chdir(outputdir)
        os.chdir(cwd)
        shutil.rmtree(outputdir, ignore_errors=True)
        os.rmdir(outputdir)
        os.mkdir(outputdir)
    except FileNotFoundError:
        os.mkdir(outputdir)
    os.chdir(cwd)
    outputdir = outputdir+'/'
    print('\r')
    t0 = time.time(); k = 0
    while k <= maxit:
        result = CorrectVramp(k, tbreak=tbreak, d=diam, A=Area, Ra=Ra, 
                        Raccess=Raccess, Rseal=Rseal, Cm=Cm, LJP=LJP,  
                        t=t, V=V, I=I, Iunit='pA', V_LJP_corrected = 'yes',  
                        poly=poly, DV=DV, data_lw = 5.0, cwd = cwd, gLfrac = gLfrac, 
                        color=['0.6','0.8'], coxdir=coxdir, maxit=maxit, criterion = criterion, 
                        do_plots=do_plots, tVIfile='', flagfile=flagfile, 
                        VRm=VRm, options = options, parameter_file = parameter_file, 
                        maxIerror_tol = maxIerror_tol, Icap_error_tol = Icap_error_tol)

        if k > 0:
            runtime = time.time()-t0
            result['Run time (s)'] = runtime
            Cm = result['Cm (uF/cm^2)']
            maxIerror = result['maxIerror (pA)']
            Icap_error = result['Icap_error (pA)']
            print('Iteration: ',k-1)
            print('   Max I error (pA): %7.3f'%maxIerror)
            print('    Icap error (pA): %7.3f'%Icap_error)
            if criterion == 'I&Icap': print('       Cm (uF/cm^2): %6.2f'%Cm)
            print('       Run time (s): %5.1f'%runtime)            
            print('\r')
            if k == 1:
                printfile = open('printout.txt','w')
            else:
                printfile = open('printout.txt','a')
            print('Iteration: ',k-1,file=printfile)
            print('   Max I error (pA): %7.3f'%maxIerror,file=printfile)
            print('    Icap error (pA): %7.3f'%Icap_error,file=printfile)
            if criterion == 'I&Icap': print('       Cm (uF/cm^2): %6.2f'%Cm,file=printfile)
            print('       Run time (s): %5.1f'%runtime,file=printfile)            
            print('',file=printfile)
            printfile.close()
            if k == 1:
                min_maxIerror = abs(maxIerror)
                min_Icap_error = abs(Icap_error)
                k0 = 0
            else:
                if (criterion == 'I' or criterion == 'I&Icap'):
                    if min_Icap_error > abs(Icap_error):
                        min_Icap_error = abs(Icap_error)
                    if min_maxIerror > abs(maxIerror): 
                        min_maxIerror = abs(maxIerror)
                        k0 = k-1
            file = open(coxdir+'/IterationTimeErrors_'+str(k-1)+'.txt','w')
            file.write('       Iteration: %d'%(k-1)+'\r')
            file.write('    Run time (s): %5.1f'%runtime+'\r')
            file.write('Max I error (pA): %7.3f'%maxIerror+'\r')
            file.write(' Icap error (pA): %7.3f'%Icap_error+'\r')
            file.close()
            if result['done'] == 1:
                k0 = k-1; plt.close(k)
                break
                
        delete_file(flagfile); flag = ''
        sb.run('neuron.exe '+neuron_file)
        while len(flag) == 0:
            try:
                file = open(flagfile,'r')
                data = file.readlines()
                flag = data[0]
                file.close()
                if 'Done' not in data[0]:
                    print('')
                    print(data[0])
                    print('')
                    raise ValueError('Execution terminated by NEURON model.')
            except (FileNotFoundError,IndexError):
                pass
        k = k + 1
    print('The smallest maximum I error was obtained with iteration '+str(k0)+'.')
    if min_maxIerror > maxIerror_tol: print('Unable to satisfy maxIerror_tol.')
    if criterion == 'I&Icap' and min_Icap_error > Icap_error_tol: 
        print('Unable to satisfy Icap_error_tol.')
    print('\r')

    os.chdir(coxdir)
    file = 'cd_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    file = 'CmRmL_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    file = 'Ierror_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    file = 'PredIcapIholdVholdVrest_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    file = 'Raw_tVpredI_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    file = 'tVpredI_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    fn = tVIfile.split('.')[0]; 
    file = 'Pred_'+fn+'_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    file = 'IterationTimeErrors_'+str(k0)+'.txt'
    shutil.copy(file, '../'+outputdir+'/'+file)
    os.chdir(cwd)
    shutil.copy('printout.txt', outputdir+'/'+'printout.txt')
    shutil.copy(parameter_file, outputdir+'/'+parameter_file)
    shutil.copy(tVIfile, outputdir+'/'+tVIfile)
    shutil.copy('Raw_tVI.txt', outputdir+'/'+'Raw_tVI.txt')
    shutil.copy('tVI.txt', outputdir+'/'+'tVI.txt')
    shutil.copy('IcapIholdVholdVrest.txt', outputdir+'/'+'IcapIholdVholdVrest.txt')
    if saveCox == 'yes': shutil.copytree(coxdir, outputdir+'/'+coxdir)
    
    if do_plots == 'yes': 
        if k > maxit:
            kf = k
        else:
            kf = k + 1
    else:
        kf = 1
    
    if Raccess > 0:
        rawt,rawV,rawI = load_xyz('Raw_tVI.txt',0,1,2)
        t,V,I = load_xyz('tVI.txt',0,1,2)
        plt.close(kf)
        fig1 = plt.figure(kf)
        plt.plot(t,V,linewidth=1.0,color='0.6')
        plt.plot(rawt,rawV,'k-',linewidth=1.0)
        plt.xlabel('$t$ (ms)')
        plt.ylabel('$V$ (mV)')
        legend = ['Raw V','Corrected V']
        plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
        plt.title('Effect of an access resistance on $V$')

    fn = outputdir+'/'+'Raw_tVpredI_'+str(k0)+'.txt'
    rawpredV,rawpredI = load_xy(fn,1,2)
    fn = outputdir+'/'+'tVpredI_'+str(k0)+'.txt'
    predV,predI = load_xy(fn,1,2)
    fn = outputdir+'/'+'Raw_tVI.txt'
    rawV,rawI = load_xy(fn,1,2)
    fn = outputdir+'/'+'tVI.txt'
    V,I = load_xy(fn,1,2)
    fig2 = plt.figure(kf+1)
    plt.plot(rawV,rawI,linewidth=5.0,color='0.6')
    plt.plot(rawpredV,rawpredI,'k-',linewidth=1.5)
    plt.plot(V,I,linewidth=5.0,color='0.8')
    plt.plot(V,predI,'b-',linewidth=1.5)
    plt.xlabel('$V$ (mV)')
    plt.ylabel('$I$ (pA)')
    legend = ['Obs raw I','Predicted','Obs crct I','Predicted']
    plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
    if Rseal == np.Inf:
        plt.title('Raw I and I corrected for Cm')
    else:
        plt.title('Raw I and I corrected for Rseal and Cm')
    fn = outputdir+'/'+'cd_'+str(k0)+'.txt'
    cdV,cd = load_xy(fn,0,1)
    file = open(outputdir+'/'+'CmRmL_'+str(k0)+'.txt','r')
    data = file.readlines(); file.close()
    gL = 0; i = 0
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':'); v[0] = v[0].strip()
        if v[0] == 'gL (S/cm^2)': gL = float(v[1])
        if v[0] == 'ELeak (mV)' and gL > 0: EL = float(v[1])
        i = i + 1
    fig3 = plt.figure(kf+2); mult = 1
    if np.min(np.abs(cd)) < 0.01: mult = 1000
    plt.plot(cdV,mult*cd,'k-'); iL = []
    legend = ['i']
    if gL > 0 and plot_gL == 'yes':
        iL.append(gL*(V[0] - EL))
        iL.append(gL*(V[len(V)-1] - EL))
        plt.plot([V[0],V[len(V)-1]],mult*np.array(iL),'b--')
        legend.append('iL')
    if len(VRm) > 0 and plot_Rm == 'yes':
        i = 0; n = len(cd)
        if VRm[0] < V[1]: VRm[0] = V[1]
        while i < n:
            if i > 0:
                if cdV[i-1] <= VRm[0] and VRm[0] <= cdV[i]: 
                    iRm0 = linterpol(cdV[i-1],cd[i-1],cdV[i],cd[i],VRm[0])
                if cdV[i-1] <= VRm[1] and VRm[1] <= cdV[i]: 
                    iRm1 = linterpol(cdV[i-1],cd[i-1],cdV[i],cd[i],VRm[1])
            i = i + 1
        plt.plot([VRm[0],VRm[1]],mult*np.array([iRm0,iRm1]),'y-.')
        legend.append('Rm')
    plt.xlabel('$V$ (mV)')
    if mult == 1:
        plt.ylabel('Current density (mA cm$^{\minus2}$)')
    else:
        plt.ylabel('Current density ($\\times10^{\minus3}$ mA cm$^{\minus2}$)')
    plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
    plt.title('Best-fit current density')

    result['cd (mA/cm^2)'] = cd
    result['Best iteration'] = k0
    return result
